(() => {
  const canvas = document.getElementById('stage');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const W = canvas.width;
  const H = canvas.height;
  const U = 3;
  const FLOOR = 114;
  const WALL = 100;
  const PX = 52;
  const EDGE = 44;
  const reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  ctx.imageSmoothingEnabled = false;

  const PLAYER_MAP = [
    '....hhhhhh....',
    '...hhhhhhhh...',
    '...hsssssshh..',
    '...hggggggs...',
    '...hsssssssy..',
    '....ssssss....',
    '....cccccc....',
    '..cccccccccc..',
    '.cccccccccccc.',
    '.cdccccccccss.',
    '.cdcccccccccc.',
    '..dccbbbbccc..',
    '...ccppppcc...',
    '....ppp..ppp..',
    '....ppp..ppp..',
    '....ppp..ppp..',
    '...oooo..oooo.',
    '...oooo..oooo.',
  ];
  const PLAYER_PAL = {
    h: '#3b2a55', s: '#f5cfa6', g: '#3dd9ff', y: '#ffc542', c: '#1fb5a0',
    d: '#0f6e63', b: '#c78b1a', p: '#2a3f8a', o: '#0b0f14',
  };

  const mirror = (half) => half.map((row) => row + row.split('').reverse().join(''));

  const BITSY_MAP = mirror([
    '..g.......',
    '...g......',
    '....kkkkkk',
    '...kddddgg',
    '...kdyydgg',
    '...kddddgg',
    '....kkkkkk',
    '..kkgggggg',
    '.kgggdgggw',
    'kgggdddggw',
    'kggdgggggw',
    'kgggggdggw',
    '.kgggggggw',
    '..kkgggggg',
    '...kkkkkkk',
    '.k.k......',
    'k.k.......',
  ]);
  const BITSY_PAL = { g: '#39ff88', d: '#0f6e3b', k: '#04140b', y: '#ffc542', w: '#e8fff2' };

  const GUS_MAP = mirror([
    '...kkkkkkkkk',
    '..kSSSSSSSSS',
    '..kSssssssss',
    '..ksskeeekss',
    '..ksskeeekss',
    '..ksssssssss',
    '..kdkdkdkdkd',
    '..ksssssssss',
    '...kkkkkkkkk',
    '..kkSSSSSSSS',
    '.kSSssssssss',
    '.kSsdddddddd',
    '.kSsdccccccc',
    '.kSsdcdddddd',
    '.kSsdcddyyyy',
    '.kSsdcdddddd',
    '.kSsdccccccc',
    '.kSsdddddddd',
    '.kSsssssssss',
    '..kkssssssss',
    '...kssssk...',
    '...kssssk...',
    '...kddddk...',
    '..kkkkkkk...',
  ]);
  const GUS_PAL = {
    s: '#8a96a3', S: '#b4c0cc', d: '#3f4a55', k: '#0b0f14', e: '#39ff88', c: '#3dd9ff', y: '#ffc542',
  };

  const SYNTAX_MAP = mirror([
    '..........kkk',
    '.........kpPP',
    '.........kyyP',
    '.........kpPP',
    '........kkrrk',
    '.......kkpppp',
    '......kpPPPPP',
    '.....kpPPpppp',
    '....kpPppprrr',
    '....kpppppprr',
    '....kpPpppprr',
    '.....kpPppppp',
    '......kpppppp',
    '.......kkkppp',
    '..........kkk',
  ]);
  const SYNTAX_PAL = { k: '#0b0714', p: '#5b2a86', P: '#8f52c2', r: '#ff4d5e', y: '#ffc542' };

  const DOG_RECTS = [
    [9, 5, 19, 6, 'k'], [10, 4, 17, 1, 'K'],
    [15, 11, 3, 3, 'K'], [15, 13, 3, 1, 't'], [26, 11, 3, 3, 'K'], [26, 13, 3, 1, 't'],
    [10, 11, 3, 4, 'k'], [10, 14, 3, 1, 't'], [22, 11, 3, 4, 'k'], [22, 14, 3, 1, 't'],
    [12, 10, 11, 1, 't'],
    [3, 3, 8, 6, 'k'], [4, 2, 5, 1, 'K'],
    [9, 8, 3, 3, 't'],
    [2, 6, 3, 3, 't'], [0, 6, 2, 2, 'n'], [6, 7, 2, 1, 't'],
    [5, 3, 1, 1, 't'], [5, 4, 1, 1, 'w'],
    [8, 4, 3, 5, 'K'], [9, 9, 2, 1, 'K'],
    [11, 5, 1, 5, 'c'], [11, 10, 2, 2, 'y'],
    [28, 4, 2, 3, 'k'], [29, 2, 2, 3, 'k'], [30, 1, 1, 2, 'K'], [28, 7, 2, 1, 't'],
  ];
  const DOG_MAP = (() => {
    const grid = Array.from({ length: 16 }, () => Array(32).fill('.'));
    DOG_RECTS.forEach(([x, y, w, h, c]) => {
      for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) grid[j][i] = c;
    });
    return grid.map((r) => r.join(''));
  })();
  const DOG_PAL = {
    k: '#1f1815', K: '#3b302a', t: '#c27a3a', w: '#fff7e6', n: '#050403', c: '#3dd9ff', y: '#ffc542',
  };

  const WARDEN_MAP = mirror([
    '....r........',
    '....k........',
    '....k........',
    '..kkkkkkkkkkk',
    '..kllllllllll',
    '..klmmmmmmmmm',
    '..klmkkkkkkkk',
    '..klmkrrrrkkk',
    '..klmkrRRrkkk',
    '..klmkrrrrkkk',
    '..klmkkkkkkkk',
    '..klmkykykyky',
    '..klmkkkkkkkk',
    '..klmmmmmmmmm',
    '..kllllllllll',
    '..kkkkkkkkkkk',
    '...kmmmmmmmmm',
    '...kmgykklklk',
    '...kmmmmmmmmm',
    '...kmcgkklklk',
    '...kmmmmmmmmm',
    '...kmyckklklk',
    '...kmmmmmmmmm',
    '...kkkkkkkkkk',
    '....kkk......',
    '....kkk......',
  ]);
  const WARDEN_PAL = {
    k: '#06090c', l: '#5b7a8c', m: '#2a3d4a', r: '#ff4d5e', R: '#ffd0d4',
    y: '#ffc542', g: '#39ff88', c: '#3dd9ff',
  };

  const PAT = {
    bug: ['..x..', '.xxx.', 'xxxxx', '.xxx.', '..x..'],
    bolt: ['...xx', '..xx.', '.xxxx', '..xx.', '.xx..'],
    bone: ['xx...xx', 'xxxxxxx', 'xx...xx'],
    cross: ['x...x', '.x.x.', '..x..', '.x.x.', 'x...x'],
    one: ['.x.', 'xx.', '.x.', '.x.', 'xxx'],
    zero: ['xxx', 'x.x', 'x.x', 'x.x', 'xxx'],
  };

  function build(map, pal, unit, solid) {
    const c = document.createElement('canvas');
    c.width = map[0].length * unit;
    c.height = map.length * unit;
    const g = c.getContext('2d');
    map.forEach((row, y) => {
      for (let x = 0; x < row.length; x++) {
        const ch = row[x];
        if (ch === '.') continue;
        g.fillStyle = solid || pal[ch];
        g.fillRect(x * unit, y * unit, unit, unit);
      }
    });
    return c;
  }

  function makeEnemy(def) {
    const e = Object.assign({ lift: 0, count: 2, hover: false }, def);
    e.spr = {
      n: build(e.map, e.pal, e.u),
      a: build(e.map, Object.assign({}, e.pal, e.angry), e.u),
      w: build(e.map, e.pal, e.u, '#ffffff'),
    };
    if (e.extraPals) {
      Object.keys(e.extraPals).forEach((k) => {
        e.spr[k] = build(e.map, Object.assign({}, e.pal, e.extraPals[k]), e.u);
      });
    }
    e.width = e.spr.n.width;
    e.height = e.spr.n.height;
    return e;
  }

  const ENEMIES = [
    makeEnemy({
      name: 'BITSY', u: 4, map: BITSY_MAP, pal: BITSY_PAL, angry: { y: '#ff4d5e', g: '#7dffb0' },
      shot: { pats: ['one', 'zero'], color: '#39ff88' }, bg: 'boot', fire: 0.35, tint: ['#03100a', '#0a3a22'],
    }),
    makeEnemy({
      name: 'GUS', u: 3, map: GUS_MAP, pal: GUS_PAL, angry: { e: '#ff4d5e', y: '#ff4d5e' },
      shot: { pats: ['bolt'], color: '#ffe14d' }, bg: 'logic', fire: 0.4, tint: ['#04120a', '#0b3d25'],
    }),
    makeEnemy({
      name: 'SENTRY', u: 3, map: DOG_MAP, pal: DOG_PAL, angry: { w: '#ff4d5e', c: '#ff4d5e' },
      shot: { pats: ['bone'], color: '#f1e6d0' }, bg: 'network', fire: 0.7, tint: ['#050c1c', '#12306b'],
    }),
    makeEnemy({
      name: 'MADAME SYNTAX', u: 3, map: SYNTAX_MAP, pal: SYNTAX_PAL, angry: { y: '#ff4d5e', r: '#ffd0d4' },
      shot: { pats: ['cross'], color: '#ff4d5e' }, bg: 'debug', fire: 0.45, legs: true, tint: ['#0b0613', '#2a1650'],
    }),
    makeEnemy({
      name: 'WARDEN', u: 3, map: WARDEN_MAP, pal: WARDEN_PAL, angry: { r: '#ff1f3a', R: '#ffffff', y: '#ff4d5e' },
      extraPals: {
        dark: { r: '#3a1218', R: '#5a2a30', y: '#3a3010' },
        friendly: { r: '#3dd9ff', R: '#ffffff', y: '#39ff88' },
      },
      shot: { pats: ['bug'], color: '#ff4d5e' }, bg: 'vault', count: 3, hover: true, lift: 8, cables: true, fire: 0.3,
      tint: ['#0a0808', '#3a2a2a'],
    }),
  ];

  const B = {
    t: 0, name: 'PLAYER', level: 1, lives: 3, maxLives: 3, god: false, init: false, ended: false,
    idx: -1, intro: false, bg: 'racks', e: ENEMIES[4],
    pShown: 3, pTarget: 3, wShown: 15, wTarget: 15, wMax: 15,
    p: { flash: 0, shake: 0, swing: -1, dead: 0, dying: false },
    w: { flash: 0, shake: 0, atk: 0, laugh: 0, dead: 0, mode: 'alive', style: 'explode', enter: 0 },
    ex: 0, ey: 0,
    shots: [], parts: [], pops: [], pendingHit: null, pendingFinal: false, lastQ: 0,
  };

  function freshEnemyState(enter) {
    return { flash: 0, shake: 0, atk: 0, laugh: 0, dead: 0, mode: 'alive', style: 'explode', enter: enter || 0 };
  }

  function setEnemy(idx, bg, hp, max, instant) {
    B.idx = idx;
    B.e = ENEMIES[idx];
    B.bg = bg;
    B.w = freshEnemyState(instant ? 0 : 1);
    B.wMax = max;
    B.wShown = B.wTarget = hp;
    B.shots = B.shots.filter((s) => s.kind === 'beam');
  }

  function reset() {
    B.init = false;
    B.ended = false;
    B.intro = false;
    B.lastQ = 0;
    B.pShown = B.pTarget = B.lives = B.maxLives = 3;
    B.god = false;
    B.p = { flash: 0, shake: 0, swing: -1, dead: 0, dying: false };
    B.shots = [];
    B.parts = [];
    B.pops = [];
    B.pendingHit = null;
    setEnemy(4, 'racks', 15, 15, true);
  }

  function burst(x, y, n, colors, speed) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = (0.4 + Math.random()) * (speed || 2.4);
      B.parts.push({
        x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 0.6, life: 28 + Math.random() * 26,
        color: colors[Math.floor(Math.random() * colors.length)], size: Math.random() < 0.5 ? 2 : 3,
      });
    }
  }

  function pop(text, x, y, color, size, life) {
    B.pops.push({ text, x, y, color, size: size || 10, life: life || 56 });
  }

  function playerCenter() {
    return { x: PX + PW / 2, y: FLOOR - PH / 2 };
  }

  function enemyCenter() {
    return { x: B.ex + B.e.width / 2, y: B.ey + B.e.height / 2 };
  }

  const PW = 14 * U;
  const PH = 18 * U;
  const SPR = {
    player: build(PLAYER_MAP, PLAYER_PAL, U),
    playerWhite: build(PLAYER_MAP, PLAYER_PAL, U, '#ffffff'),
  };

  function playerAttack(onHit, big) {
    if (B.p.dying) {
      onHit();
      return;
    }
    B.p.swing = 0;
    B.pendingHit = onHit;
    B.pendingFinal = !!big;
  }

  function fireBeam(big) {
    const color = B.god ? ['#ffffff', '#ffc542', '#ffe08a'] : ['#ffffff', '#3dd9ff', '#39ff88'];
    B.shots.push({
      kind: 'beam', x: PX + PW + 14, y: FLOOR - PH + 9 * U, vx: big ? 8 : 9, vy: 0, delay: 0,
      big: !!big, color, onHit: B.pendingHit || (() => {}),
    });
    B.pendingHit = null;
  }

  function enemyAttack(onHit) {
    const e = B.e;
    B.w.atk = 34;
    const lowShot = e.name === 'SENTRY';
    const base = lowShot ? B.ey + B.e.height - 30 : B.ey + Math.round(B.e.height * 0.28);
    for (let i = 0; i < e.count; i++) {
      B.shots.push({
        kind: 'foe', x: B.ex + 6, y: base + i * (lowShot ? 8 : 14), vx: -5.2, vy: 0, delay: i * 11,
        pat: e.shot.pats[Math.floor(Math.random() * e.shot.pats.length)], color: e.shot.color,
        onHit: i === 0 ? onHit : () => {}, main: i === 0,
      });
    }
  }

  function hurtEnemy() {
    B.w.flash = 12;
    B.w.shake = 16;
    const c = enemyCenter();
    burst(c.x, c.y, 22, ['#ffffff', '#ffc542', '#ff4d5e', '#3dd9ff'], 2.6);
  }

  function hurtPlayer() {
    B.p.flash = 14;
    B.p.shake = 16;
    const c = playerCenter();
    burst(c.x, c.y, 22, ['#ff4d5e', '#ffffff', '#ffc542'], 2.6);
  }

  function block() {
    const c = playerCenter();
    B.p.flash = 4;
    burst(c.x + 18, c.y, 18, ['#ffc542', '#ffffff', '#ffe08a'], 2.8);
    pop('BLOCKED', c.x, c.y - 32, '#ffc542', 9);
  }

  function defeatEnemy() {
    if (B.w.mode !== 'alive') return;
    const c = enemyCenter();
    if (B.idx === 4) {
      B.w.mode = 'stunned';
      burst(c.x, c.y, 50, ['#ffffff', '#ffc542', '#3dd9ff'], 3.4);
      setTimeout(() => pop('STUNNED!', W / 2, 58, '#ffc542', 14, 110), 350);
    } else {
      B.w.mode = 'dying';
      B.w.style = 'debug';
      burst(c.x, c.y, 60, ['#39ff88', '#ffffff', '#3dd9ff'], 3.4);
      setTimeout(() => pop('DEBUGGED!', W / 2, 58, '#39ff88', 14, 110), 350);
    }
  }

  function explodeBoss() {
    if (B.w.mode === 'dying') return;
    const c = enemyCenter();
    B.w.mode = 'dying';
    B.w.style = 'explode';
    burst(c.x, c.y, 90, ['#ffffff', '#ffc542', '#ff4d5e', '#3dd9ff', '#39ff88'], 5);
    setTimeout(() => pop('VICTORY!', W / 2, 58, '#39ff88', 16, 120), 500);
  }

  function patchBoss() {
    if (B.w.mode === 'patched') return;
    const c = enemyCenter();
    B.w.mode = 'patched';
    burst(c.x, c.y, 70, ['#3dd9ff', '#ffffff', '#39ff88'], 3.6);
    setTimeout(() => pop('PATCHED!', W / 2, 58, '#3dd9ff', 16, 120), 500);
  }

  function killPlayer(timeout) {
    if (B.p.dying) return;
    B.p.dying = true;
    B.w.laugh = 140;
    setTimeout(() => pop(timeout ? 'TIME OUT' : 'GAME OVER', W / 2, 58, '#ff4d5e', 16, 120), 500);
  }

  function godBurst() {
    const c = playerCenter();
    burst(c.x, c.y, 70, ['#ffc542', '#ffffff', '#ffe08a'], 4);
    pop('GOD MODE', c.x, c.y - 30, '#ffc542', 12, 90);
  }

  function sync(state, result) {
    const hud = state.hud;
    result = result || {};
    if (!hud || state.phase === 'menu') {
      reset();
      return;
    }
    const fx = result.fx;
    if (hud.god && !B.god) godBurst();
    B.name = hud.name;
    B.level = hud.room + 1;
    B.maxLives = hud.max_lives;
    B.god = hud.god;
    B.lives = hud.lives;
    const fresh = !B.init;
    if (fresh) {
      B.init = true;
      B.pShown = B.pTarget = hud.lives;
    }

    const intro = state.phase === 'intro';
    const idx = intro ? 4 : hud.room;
    const bg = intro ? 'racks' : ENEMIES[idx].bg;
    const hp = intro ? 15 : hud.enemy_hp;
    const max = intro ? 15 : hud.enemy_max;
    if (idx !== B.idx || bg !== B.bg) setEnemy(idx, bg, hp, max, fresh);
    B.wMax = max;

    if (fx === 'correct') {
      const dmg = result.damage || 1;
      const crit = !!result.crit;
      playerAttack(() => {
        B.wTarget = hp;
        const c = enemyCenter();
        pop(crit ? 'CRIT -' + dmg + '!' : '-' + dmg, c.x, c.y - 34, crit ? '#ffc542' : '#ffffff', crit ? 13 : 11);
        hurtEnemy();
        if (hp <= 0) defeatEnemy();
      }, crit || hp <= 0);
    } else {
      B.wTarget = hp;
      if (hp <= 0 && !intro && state.phase !== 'end') {
        if (idx === 4) B.w.mode = B.w.mode === 'alive' ? 'stunned' : B.w.mode;
        else if (B.w.mode === 'alive') {
          B.w.mode = 'dying';
          B.w.dead = 1;
        }
      }
    }

    if (fx === 'wrong' || fx === 'vault_reset') {
      enemyAttack(() => {
        if (hud.god) {
          block();
        } else {
          B.pTarget = hud.lives;
          const c = playerCenter();
          pop('-1', c.x, c.y - 32, '#ff4d5e', 12);
          hurtPlayer();
        }
      });
    } else {
      B.pTarget = hud.lives;
    }

    if (fx === 'powerup') {
      const c = playerCenter();
      burst(c.x, c.y, 30, ['#39ff88', '#ffffff', '#3dd9ff'], 2.2);
      pop('+', c.x, c.y - 32, '#39ff88', 12);
    } else if (fx === 'hint') {
      const c = playerCenter();
      pop('?', c.x, c.y - 32, '#3dd9ff', 14);
    } else if (fx === 'vault_miss') {
      B.w.laugh = 30;
    }

    if (state.phase === 'question' && state.question.id !== B.lastQ) {
      B.lastQ = state.question.id;
      if (state.question.ability) {
        B.w.atk = 22;
        const move = state.question.ability.title.replace(/^.*USES /, '');
        const c = enemyCenter();
        pop(move, c.x, c.y - 40, '#ffc542', 11, 80);
      }
    }

    if (state.phase === 'end' && !B.ended) {
      B.ended = true;
      const ending = state.end.ending;
      setTimeout(() => {
        if (ending === 'delete') explodeBoss();
        else if (ending === 'patch') patchBoss();
        else killPlayer(ending === 'time');
      }, fx ? 700 : 250);
    }
    if (state.phase !== 'end') B.ended = false;
  }

  const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
  bgGrad.addColorStop(0, '#0a1c28');
  bgGrad.addColorStop(1, '#04080b');

  function bgRacks() {
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, WALL);
    if (!reduced) {
      ctx.font = '8px monospace';
      ctx.textAlign = 'left';
      for (let i = 0; i < 14; i++) {
        const speed = 0.3 + (i % 5) * 0.11;
        const y = ((B.t * speed + i * 37) % (H + 20)) - 10;
        ctx.fillStyle = 'rgba(57,255,136,0.13)';
        ctx.fillText(((i + Math.floor(B.t / 9)) % 2) ? '1' : '0', i * 29 + 7, y);
      }
    }
    for (let i = 0; i < 13; i++) {
      const x = i * 32 + 4;
      ctx.fillStyle = '#071722';
      ctx.fillRect(x, 40, 24, WALL - 40);
      ctx.fillStyle = '#0e3340';
      ctx.fillRect(x, 40, 24, 1);
      ctx.fillRect(x, 40, 1, WALL - 40);
      ctx.fillRect(x + 23, 40, 1, WALL - 40);
      for (let j = 0; j < 7; j++) {
        const y = 46 + j * 8;
        ctx.fillStyle = '#0b2430';
        ctx.fillRect(x + 3, y, 12, 3);
        const on = ((Math.floor(B.t / 28) + i + j * 2) % 4) < 2;
        ctx.fillStyle = (i + j) % 3 === 0 ? (on ? '#ff4d5e' : '#3a1218') : (on ? '#39ff88' : '#0d3a22');
        ctx.fillRect(x + 18, y, 3, 3);
      }
    }
  }

  function bgBoot() {
    ctx.fillStyle = '#02070a';
    ctx.fillRect(0, 0, W, WALL);
    const speed = 0.35;
    const k = Math.floor(B.t * speed / 12);
    const scroll = (B.t * speed) % 12;
    for (let i = 0; i < 9; i++) {
      const y = 36 + i * 12 - scroll;
      const seed = (i + k) * 7919;
      const w = 40 + (seed % 190);
      ctx.fillStyle = 'rgba(57,255,136,0.2)';
      ctx.fillRect(14, y, w, 3);
      ctx.fillStyle = 'rgba(57,255,136,0.1)';
      ctx.fillRect(14 + w + 6, y, 14 + (seed % 40), 3);
    }
    ctx.font = 'bold 8px monospace';
    ctx.textAlign = 'left';
    const pct = Math.floor((B.t * 0.5) % 100);
    ctx.fillStyle = 'rgba(57,255,136,0.55)';
    ctx.fillText('SYSTEM BOOT v1.0  ' + pct + '%', 62, 83);
    ctx.fillStyle = '#39ff88';
    if ((B.t >> 5) & 1) ctx.fillRect(196, 75, 5, 9);
    ctx.strokeStyle = 'rgba(57,255,136,0.5)';
    ctx.strokeRect(60.5, 86.5, 280, 6);
    ctx.fillStyle = 'rgba(57,255,136,0.55)';
    ctx.fillRect(62, 88, 277 * (pct / 100), 3);
  }

  function bgLogic() {
    ctx.fillStyle = '#031208';
    ctx.fillRect(0, 0, W, WALL);
    const rows = [30, 44, 58, 72, 86];
    const cols = [40, 110, 180, 250, 320, 380];
    ctx.fillStyle = '#0c3d22';
    rows.forEach((y, i) => {
      ctx.fillRect(i % 2 ? 0 : 20, y, i % 2 ? W - 30 : W - 10, 2);
    });
    cols.forEach((x, i) => {
      ctx.fillRect(x, i % 2 ? 14 : 8, 2, WALL - (i % 2 ? 16 : 10));
    });
    [[22, 46], [150, 20], [300, 60], [214, 76]].forEach(([x, y]) => {
      ctx.fillStyle = '#0a2a1a';
      ctx.fillRect(x, y, 44, 24);
      ctx.fillStyle = '#14603a';
      ctx.fillRect(x, y, 44, 1);
      ctx.fillRect(x, y + 23, 44, 1);
      ctx.fillRect(x, y, 1, 24);
      ctx.fillRect(x + 43, y, 1, 24);
      for (let p = 0; p < 6; p++) {
        ctx.fillRect(x + 4 + p * 7, y - 3, 2, 3);
        ctx.fillRect(x + 4 + p * 7, y + 24, 2, 3);
      }
      ctx.fillStyle = ((B.t >> 4) & 1) ? '#39ff88' : '#0d3a22';
      ctx.fillRect(x + 6, y + 9, 5, 5);
    });
    for (let i = 0; i < 6; i++) {
      const x = (B.t * 1.4 + i * 75) % W;
      ctx.fillStyle = '#7dffb0';
      ctx.fillRect(x, rows[i % rows.length] - 1, 8, 4);
      const vy = (B.t * 1.1 + i * 40) % WALL;
      ctx.fillRect(cols[i % cols.length] - 1, vy, 4, 8);
    }
  }

  function bgNetwork() {
    ctx.fillStyle = '#030b18';
    ctx.fillRect(0, 0, W, WALL);
    const colors = ['#3dd9ff', '#ffc542', '#ff4d5e', '#39ff88', '#b36bff', '#ff8f3d'];
    const wave = (x, j) => 26 + j * 11 + Math.sin(x * 0.045 + B.t * 0.02 + j) * 5;
    for (let j = 0; j < 6; j++) {
      ctx.fillStyle = colors[j];
      ctx.globalAlpha = 0.45;
      for (let x = 0; x < W; x += 4) ctx.fillRect(x, wave(x, j), 4, 3);
    }
    ctx.globalAlpha = 1;
    for (let k = 0; k < 9; k++) {
      const x = (B.t * (1.2 + (k % 3) * 0.4) + k * 47) % W;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(x, wave(x, k % 6) - 1, 6, 5);
    }
    ctx.strokeStyle = 'rgba(61,217,255,0.4)';
    ctx.lineWidth = 2;
    [10, 18, 26].forEach((r, i) => {
      ctx.globalAlpha = 0.25 + 0.5 * (((B.t >> 4) + i) % 3 === 0 ? 1 : 0.4);
      ctx.beginPath();
      ctx.arc(60, 96, r, -2.3, -0.8);
      ctx.stroke();
    });
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#081a33';
    ctx.fillRect(0, 88, W, 12);
    for (let i = 0; i < 24; i++) {
      ctx.fillStyle = '#0d2a52';
      ctx.fillRect(8 + i * 16, 90, 10, 7);
      const on = ((B.t >> 4) + i * 3) % 5 < 2;
      ctx.fillStyle = on ? '#39ff88' : '#0d3a22';
      ctx.fillRect(11 + i * 16, 92, 3, 3);
    }
  }

  function bgDebug() {
    ctx.fillStyle = '#0a0612';
    ctx.fillRect(0, 0, W, WALL);
    ctx.fillStyle = '#120a1f';
    ctx.fillRect(0, 0, 26, WALL);
    const palette = ['#6a4cff', '#39ff88', '#ffc542', '#3dd9ff'];
    const speed = 0.25;
    const k = Math.floor(B.t * speed / 10);
    const scroll = (B.t * speed) % 10;
    for (let i = 0; i < 11; i++) {
      const y = 6 + i * 10 - scroll;
      const idx = i + k;
      const indent = (idx * 37 % 4) * 10;
      const len = 30 + (idx * 53 % 150);
      ctx.fillStyle = '#3a2a55';
      ctx.fillRect(8, y, 10, 3);
      ctx.globalAlpha = 0.45;
      ctx.fillStyle = palette[idx % 4];
      ctx.fillRect(34 + indent, y, len, 3);
      ctx.fillStyle = palette[(idx + 1) % 4];
      ctx.fillRect(34 + indent + len + 5, y, 20 + (idx * 29 % 50), 3);
      ctx.globalAlpha = 1;
      if (idx % 7 === 3) {
        ctx.fillStyle = '#ff4d5e';
        for (let x = 34 + indent; x < 34 + indent + len; x += 4) ctx.fillRect(x, y + 4 + ((x / 4) % 2) * 1, 2, 1);
      }
    }
    ctx.fillStyle = '#1a0b12';
    ctx.fillRect(130, 40, 84, 30);
    ctx.strokeStyle = '#ff4d5e';
    ctx.strokeRect(130.5, 40.5, 84, 30);
    ctx.fillStyle = '#ff4d5e';
    ctx.fillRect(136, 46, 8, 8);
    ctx.font = 'bold 8px monospace';
    ctx.textAlign = 'left';
    ctx.fillText('SyntaxError', 150, 52);
    ctx.fillStyle = 'rgba(255,77,94,0.6)';
    ctx.fillRect(136, 60, 70, 2);
  }

  function bgVault() {
    ctx.fillStyle = '#0b0808';
    ctx.fillRect(0, 0, W, WALL);
    const alarm = (B.t >> 4) & 1;
    ctx.fillStyle = '#1d2229';
    ctx.fillRect(110, 12, 180, 88);
    ctx.fillStyle = '#2c333c';
    ctx.fillRect(116, 18, 168, 82);
    ctx.fillStyle = '#4a525c';
    [[110, 12], [284, 12], [110, 94], [284, 94]].forEach(([x, y]) => ctx.fillRect(x, y, 6, 6));
    const cx = 200;
    const cy = 56;
    ctx.strokeStyle = '#8a94a0';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy, 26, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 4; i++) {
      const a = B.t * 0.012 + i * Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(a) * 26, cy + Math.sin(a) * 26);
      ctx.stroke();
    }
    ctx.fillStyle = '#c9d1d9';
    ctx.fillRect(cx - 4, cy - 4, 8, 8);
    ctx.fillStyle = alarm ? '#ff4d5e' : '#3a1218';
    ctx.fillRect(52, 18, 12, 12);
    ctx.fillRect(336, 18, 12, 12);
    if (alarm) {
      ctx.fillStyle = 'rgba(255,77,94,0.07)';
      ctx.fillRect(0, 0, W, WALL);
    }
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ff4d5e';
    const sec = 59 - (Math.floor(B.t / 60) % 60);
    ctx.fillText('00:' + String(sec).padStart(2, '0'), cx, 10);
    for (let x = 0; x < W; x += 16) {
      ctx.fillStyle = '#c78b1a';
      ctx.fillRect(x, WALL - 5, 8, 5);
    }
  }

  const BACKDROPS = { racks: bgRacks, boot: bgBoot, logic: bgLogic, network: bgNetwork, debug: bgDebug, vault: bgVault };
  const TINTS = {
    racks: ['#05121a', '#0b2a36'], boot: ENEMIES[0].tint, logic: ENEMIES[1].tint,
    network: ENEMIES[2].tint, debug: ENEMIES[3].tint, vault: ENEMIES[4].tint,
  };

  function drawBackdrop() {
    BACKDROPS[B.bg]();
    const tint = TINTS[B.bg];
    ctx.fillStyle = tint[0];
    ctx.fillRect(0, WALL, W, H - WALL);
    ctx.fillStyle = tint[1];
    ctx.fillRect(0, WALL, W, 1);
    ctx.strokeStyle = tint[1];
    ctx.globalAlpha = 0.7;
    ctx.lineWidth = 1;
    ctx.beginPath();
    [106, 114, 125].forEach((y) => {
      ctx.moveTo(0, y + 0.5);
      ctx.lineTo(W, y + 0.5);
    });
    for (let k = -8; k <= 8; k++) {
      ctx.moveTo(W / 2 + k * 18, WALL);
      ctx.lineTo(W / 2 + k * 66, H);
    }
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  function dissolve(map, pal, unit, x, y, progress, rise) {
    for (let py = 0; py < map.length; py++) {
      const row = map[py];
      for (let px = 0; px < row.length; px++) {
        const ch = row[px];
        if (ch === '.') continue;
        const hash = (((px * 73856093) ^ (py * 19349663)) >>> 0) % 1000 / 1000;
        if (hash < progress) continue;
        ctx.fillStyle = pal[ch];
        ctx.fillRect(x + px * unit, y + py * unit + rise * progress, unit, unit);
      }
    }
  }

  function drawShadow(x, w, strength) {
    ctx.fillStyle = 'rgba(0,0,0,' + strength + ')';
    ctx.fillRect(x + 4, FLOOR - 1, w - 8, 4);
    ctx.fillRect(x + 8, FLOOR + 3, w - 16, 2);
  }

  function drawCables(wx, wy, fade) {
    const angry = B.w.atk > 0;
    [-1, 1].forEach((side) => {
      const baseX = side < 0 ? wx + 4 * U : wx + B.e.width - 4 * U;
      const baseY = wy + 17 * U;
      const len = (side < 0 ? (angry ? 62 : 38) : 36) * (1 - fade);
      const n = 10;
      for (let i = 0; i <= n; i++) {
        const k = i / n;
        const x = baseX + side * k * len;
        const y = baseY + Math.sin(B.t * 0.08 + i * 0.7 + side) * 5 * k + k * k * (angry && side < 0 ? 4 : 20);
        ctx.fillStyle = i % 2 ? '#2d4351' : '#1a2832';
        ctx.fillRect(Math.round(x / 2) * 2, Math.round(y / 2) * 2, 4, 4);
        if (i === n) {
          ctx.fillStyle = angry ? '#ff1f3a' : '#ff4d5e';
          ctx.fillRect(Math.round(x / 2) * 2 - 2, Math.round(y / 2) * 2 - 2, 8, 8);
          ctx.fillStyle = '#ffd0d4';
          ctx.fillRect(Math.round(x / 2) * 2 + 1, Math.round(y / 2) * 2 + 1, 2, 2);
        }
      }
    });
  }

  function pixelLine(x0, y0, x1, y1, color, size) {
    const steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0)) / 2;
    for (let i = 0; i <= steps; i++) {
      const t = steps ? i / steps : 0;
      ctx.fillStyle = color;
      ctx.fillRect(Math.round((x0 + (x1 - x0) * t) / 2) * 2, Math.round((y0 + (y1 - y0) * t) / 2) * 2, size, size);
    }
  }

  function drawLegs(ex, ey, fade) {
    const cx = ex + B.e.width / 2;
    const cy = ey + B.e.height * 0.62;
    const angry = B.w.atk > 0 ? 6 : 3;
    [-1, 1].forEach((side) => {
      for (let i = 0; i < 4; i++) {
        const x0 = cx + side * (18 + i * 1.5);
        const y0 = cy + (i - 1.5) * 5;
        const x1 = x0 + side * (16 + i * 4) * (1 - fade);
        const y1 = y0 - 16 - Math.sin(B.t * 0.08 + i + side) * angry;
        const x2 = x1 + side * (10 + i * 2) * (1 - fade);
        const y2 = FLOOR - 1 - (i % 2) * 2;
        pixelLine(x0, y0, x1, y1, '#3a1f55', 3);
        pixelLine(x1, y1, x2, y2, '#5b2a86', 3);
        ctx.fillStyle = '#8f52c2';
        ctx.fillRect(Math.round(x1) - 1, Math.round(y1) - 1, 4, 4);
      }
    });
  }

  function drawEnemy() {
    const e = B.e;
    const w = B.w;
    const hover = e.hover ? Math.sin(B.t * 0.045) * 3 + (w.laugh > 0 ? Math.sin(B.t * 0.7) * 2.5 : 0) : Math.round(Math.sin(B.t * 0.08) * 1.4);
    const lunge = w.atk > 0 ? -Math.sin(Math.PI * (1 - w.atk / 34)) * 16 : 0;
    const enter = w.enter > 0 ? w.enter * w.enter * 130 : 0;
    const shake = (w.shake > 0 || w.mode === 'stunned') && !reduced ? Math.round((Math.random() - 0.5) * (w.mode === 'stunned' ? 2 : 5)) : 0;
    const x = Math.round(W - EDGE - e.width + lunge + enter + shake);
    const y = Math.round(FLOOR - e.height - e.lift + hover);
    B.ex = x;
    B.ey = y;
    if (w.mode === 'dying' && w.dead >= 1) return;
    drawShadow(x, e.width, 0.4 - (e.hover ? hover * 0.02 : 0));
    const fade = w.mode === 'dying' ? w.dead : 0;
    if (e.cables) drawCables(x, y, fade);
    if (e.legs) drawLegs(x, y, fade);
    if (w.mode === 'dying') {
      dissolve(e.map, e.pal, e.u, x, y, w.dead, w.style === 'explode' ? -16 : -24);
      return;
    }
    let sprite = e.spr.n;
    if (w.flash > 0 && w.flash % 2 === 0) sprite = e.spr.w;
    else if (w.mode === 'stunned') sprite = e.spr.dark || e.spr.n;
    else if (w.mode === 'patched') sprite = e.spr.friendly || e.spr.n;
    else if (w.atk > 0 || w.laugh > 0) sprite = e.spr.a;
    ctx.drawImage(sprite, x, y);
    if (e.name === 'WARDEN' && w.mode === 'alive' && (w.atk > 0 || w.laugh > 0 || ((B.t >> 5) & 7) === 0)) {
      ctx.fillStyle = 'rgba(255,77,94,0.22)';
      ctx.fillRect(x + 6 * U, y + 6 * U, 14 * U, 5 * U);
    }
    if (w.mode === 'patched') {
      ctx.fillStyle = 'rgba(61,217,255,0.16)';
      ctx.fillRect(x + 6 * U, y + 6 * U, 14 * U, 5 * U);
    }
  }

  function drawBlade(px, py) {
    const ox = px + 12.5 * U;
    const oy = py + 9.5 * U;
    let ang = -1.1 + Math.sin(B.t * 0.08) * 0.05;
    if (B.p.swing >= 0) {
      const k = Math.min(1, B.p.swing / 14);
      const e = 1 - Math.pow(1 - k, 3);
      ang = -2.0 + e * 2.5;
    }
    const core = B.god ? '#fff3c4' : '#ffffff';
    const edge = B.god ? '#ffc542' : '#3dd9ff';
    for (let d = 2; d <= 38; d += 3) {
      const x = Math.round((ox + Math.cos(ang) * d) / U) * U;
      const y = Math.round((oy + Math.sin(ang) * d) / U) * U;
      ctx.fillStyle = edge;
      ctx.fillRect(x - 1, y - 1, U + 2, U + 2);
      ctx.fillStyle = core;
      ctx.fillRect(x, y, U, U);
    }
    ctx.fillStyle = '#c78b1a';
    const gx = Math.round((ox + Math.cos(ang) * 2) / U) * U;
    const gy = Math.round((oy + Math.sin(ang) * 2) / U) * U;
    ctx.fillRect(gx - 3, gy - 3, 9, 9);
  }

  function drawPlayer() {
    const p = B.p;
    const bob = Math.round(Math.sin(B.t * 0.09) * 1.2);
    const lunge = p.swing >= 0 ? Math.sin(Math.PI * Math.min(1, p.swing / 24)) * 16 : 0;
    const sx = p.shake > 0 && !reduced ? Math.round((Math.random() - 0.5) * 5) : 0;
    const x = Math.round(PX + lunge + sx);
    const y = FLOOR - PH + bob;
    if (p.dead >= 1) return;
    drawShadow(PX, PW, 0.4);
    if (B.god) {
      const glow = 0.13 + Math.sin(B.t * 0.12) * 0.05;
      ctx.fillStyle = 'rgba(255,197,66,' + glow + ')';
      ctx.fillRect(x - 6, y - 12, PW + 12, PH + 18);
      ctx.fillRect(x - 12, y - 6, PW + 24, PH + 6);
      ctx.fillStyle = 'rgba(255,197,66,' + glow * 0.7 + ')';
      ctx.fillRect(x - 10, y - 16, PW + 20, PH + 24);
      ctx.fillRect(x - 16, y - 8, PW + 32, PH + 8);
    }
    if (p.dying) {
      dissolve(PLAYER_MAP, PLAYER_PAL, U, x, y, p.dead, 10);
      return;
    }
    ctx.drawImage(p.flash > 0 && p.flash % 2 === 0 ? SPR.playerWhite : SPR.player, x, y);
    drawBlade(x, y);
  }

  function drawShot(s) {
    if (s.delay > 0) return;
    if (s.kind === 'beam') {
      const len = s.big ? 9 : 5;
      for (let k = 0; k < len; k++) {
        const size = s.big ? 9 - Math.floor(k / 2) : 6 - Math.floor(k / 2);
        ctx.fillStyle = s.color[k % s.color.length];
        ctx.fillRect(Math.round(s.x - k * 8), Math.round(s.y - size / 2), size, size);
      }
      return;
    }
    const pat = PAT[s.pat];
    for (let r = 0; r < pat.length; r++) {
      for (let c = 0; c < pat[r].length; c++) {
        if (pat[r][c] !== 'x') continue;
        ctx.fillStyle = r === Math.floor(pat.length / 2) && c === Math.floor(pat[r].length / 2) ? '#ffffff' : s.color;
        ctx.fillRect(Math.round(s.x) + c * 3, Math.round(s.y) + r * 3, 3, 3);
      }
    }
  }

  function drawBar(x, y, w, h, frac, fill, track) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
    ctx.fillStyle = track;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = fill;
    ctx.fillRect(x, y, Math.max(0, Math.round(w * frac)), h);
  }

  function label(text, x, y, align, color) {
    ctx.textAlign = align;
    ctx.fillStyle = '#000000';
    ctx.fillText(text, x + 1, y + 1);
    ctx.fillStyle = color || '#d7fff0';
    ctx.fillText(text, x, y);
  }

  function drawHud() {
    ctx.font = 'bold 9px monospace';
    ctx.textBaseline = 'alphabetic';
    const name = B.name.toUpperCase().slice(0, 12);
    label(name + '  LV ' + B.level, 10, 12, 'left');
    const frac = B.god ? 1 : Math.max(0, B.pShown / B.maxLives);
    drawBar(10, 17, 100, 8, frac, '#ffc542', '#7a1c25');
    label(B.god ? 'HP \u221E' : 'HP ' + Math.max(0, B.lives) + '/' + B.maxLives, 117, 25, 'left', B.god ? '#ffc542' : '#d7fff0');

    label(B.e.name, W - 10, 12, 'right', '#ff4d5e');
    drawBar(W - 110, 17, 100, 8, Math.max(0, B.wShown / B.wMax), '#ff4d5e', '#2a0b10');
    label('HP ' + Math.ceil(Math.max(0, B.wShown)) + '/' + B.wMax, W - 117, 25, 'right');
  }

  function drawPops() {
    B.pops.forEach((p) => {
      ctx.font = 'bold ' + p.size + 'px monospace';
      ctx.textAlign = 'center';
      ctx.globalAlpha = Math.min(1, p.life / 18);
      ctx.fillStyle = '#000000';
      ctx.fillText(p.text, p.x + 1, p.y + 1);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text, p.x, p.y);
      ctx.globalAlpha = 1;
    });
  }

  function update() {
    B.t++;
    const p = B.p;
    const w = B.w;
    if (p.flash > 0) p.flash--;
    if (p.shake > 0) p.shake--;
    if (w.flash > 0) w.flash--;
    if (w.shake > 0) w.shake--;
    if (w.atk > 0) w.atk--;
    if (w.laugh > 0) w.laugh--;
    if (w.enter > 0) w.enter = Math.max(0, w.enter - 0.03);
    if (p.swing >= 0) {
      p.swing++;
      if (p.swing === 9) fireBeam(B.pendingFinal);
      if (p.swing > 26) p.swing = -1;
    }
    if (p.dying && p.dead < 1) p.dead = Math.min(1, p.dead + 0.014);
    if (w.mode === 'dying' && w.dead < 1) w.dead = Math.min(1, w.dead + 0.011);

    B.pShown += (B.pTarget - B.pShown) * 0.14;
    if (Math.abs(B.pTarget - B.pShown) < 0.02) B.pShown = B.pTarget;
    B.wShown += (B.wTarget - B.wShown) * 0.1;
    if (Math.abs(B.wTarget - B.wShown) < 0.05) B.wShown = B.wTarget;

    B.shots.forEach((s) => {
      if (s.delay > 0) {
        s.delay--;
        return;
      }
      s.x += s.vx;
      s.y += s.vy;
      if (s.kind === 'beam') {
        if (s.x >= B.ex + 10) {
          s.dead = true;
          s.onHit();
        }
      } else if (s.x <= PX + PW - 6) {
        s.dead = true;
        if (B.god) {
          if (s.main) {
            s.onHit();
          } else {
            const c = playerCenter();
            burst(c.x + 18, c.y, 8, ['#ffc542', '#ffffff'], 2);
          }
        } else {
          s.onHit();
          if (!s.main) {
            B.p.flash = 6;
            const c = playerCenter();
            burst(c.x, c.y, 8, ['#ff4d5e', '#ffffff'], 2);
          }
        }
      }
      if (s.x < -30 || s.x > W + 30) s.dead = true;
    });
    B.shots = B.shots.filter((s) => !s.dead);

    B.parts.forEach((q) => {
      q.x += q.vx;
      q.y += q.vy;
      q.vy += 0.1;
      q.life--;
    });
    B.parts = B.parts.filter((q) => q.life > 0);
    B.pops.forEach((q) => {
      q.y -= 0.35;
      q.life--;
    });
    B.pops = B.pops.filter((q) => q.life > 0);

    if (B.god && !p.dying && B.t % 5 === 0) {
      B.parts.push({
        x: PX + Math.random() * PW, y: FLOOR - Math.random() * PH * 0.6, vx: (Math.random() - 0.5) * 0.5,
        vy: -0.9 - Math.random() * 0.6, life: 30, color: Math.random() < 0.5 ? '#ffc542' : '#fff3c4', size: 2,
      });
    }
    if (w.mode === 'dying' && w.dead < 1 && B.t % 2 === 0) {
      const cols = w.style === 'debug' ? ['#39ff88', '#ffffff'] : ['#ff4d5e', '#ffc542'];
      B.parts.push({
        x: B.ex + Math.random() * B.e.width, y: B.ey + Math.random() * B.e.height, vx: (Math.random() - 0.5) * 2,
        vy: -1.2 - Math.random(), life: 34, color: cols[Math.floor(Math.random() * cols.length)], size: 3,
      });
    }
    if (w.mode === 'stunned' && B.t % 12 === 0) {
      B.parts.push({
        x: B.ex + Math.random() * B.e.width, y: B.ey + Math.random() * B.e.height * 0.6, vx: (Math.random() - 0.5) * 1.5,
        vy: 0.4, life: 24, color: '#ffc542', size: 2,
      });
    }
    if (w.mode === 'patched' && B.t % 10 === 0) {
      B.parts.push({
        x: B.ex + Math.random() * B.e.width, y: B.ey + B.e.height * 0.4, vx: (Math.random() - 0.5) * 0.6,
        vy: -0.9, life: 40, color: Math.random() < 0.5 ? '#3dd9ff' : '#39ff88', size: 3,
      });
    }
    if (p.dying && p.dead < 1 && B.t % 3 === 0) {
      B.parts.push({
        x: PX + Math.random() * PW, y: FLOOR - Math.random() * PH, vx: (Math.random() - 0.5) * 1.5,
        vy: -0.8 - Math.random(), life: 30, color: Math.random() < 0.5 ? '#1fb5a0' : '#3dd9ff', size: 3,
      });
    }
  }

  function draw() {
    drawBackdrop();
    drawEnemy();
    drawPlayer();
    B.shots.forEach(drawShot);
    B.parts.forEach((q) => {
      ctx.globalAlpha = Math.min(1, q.life / 14);
      ctx.fillStyle = q.color;
      ctx.fillRect(Math.round(q.x), Math.round(q.y), q.size, q.size);
    });
    ctx.globalAlpha = 1;
    drawHud();
    drawPops();
  }

  function frame() {
    update();
    draw();
    requestAnimationFrame(frame);
  }

  reset();
  window.Battle = { sync };
  requestAnimationFrame(frame);
})();
