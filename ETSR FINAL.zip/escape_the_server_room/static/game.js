(() => {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const screen = $('#screen');

  let S = { phase: 'menu' };
  let selectedDiff = 'normal';
  let timer = { end: 0, total: 600, running: false };
  let syncing = false, busy = false;
  let typeToken = 0;
  let pendingText = '', lastQId = 0;
  let qtimer = { on: false, end: 0, limit: 1, crit: 0 };
  let timeupBusy = false;
  let lastSecond = -1;
  let godArmed = false;
  let godOn = false;
  const KONAMI = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'];
  let konamiAt = 0;

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) el.setAttribute(k, v === true ? '' : v);
    }
    kids.flat().forEach(c => { if (c == null || c === false) return; el.append(c.nodeType ? c : document.createTextNode(c)); });
    return el;
  }

  let muted = false, ac = null;
  try { muted = localStorage.getItem('esr_muted') === '1'; } catch (e) { }
  function beep(freq, dur, type, vol, delay) {
    if (muted) return;
    try {
      ac = ac || new (window.AudioContext || window.webkitAudioContext)();
      const o = ac.createOscillator(), g = ac.createGain(), t0 = ac.currentTime + (delay || 0);
      o.type = type || 'square'; o.frequency.setValueAtTime(freq, t0);
      g.gain.setValueAtTime(vol || 0.04, t0); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + dur + 0.02);
    } catch (e) { }
  }
  const sfx = {
    click: () => beep(520, 0.05),
    correct: () => { beep(660, 0.09); beep(880, 0.14, 'square', 0.045, 0.09); },
    wrong: () => { beep(160, 0.3, 'sawtooth', 0.06); beep(110, 0.3, 'sawtooth', 0.06, 0.12); },
    power: () => { beep(440, 0.07); beep(660, 0.07, 'square', 0.04, 0.07); beep(990, 0.12, 'square', 0.04, 0.14); },
    tick: () => beep(880, 0.05, 'square', 0.05),
    win: () => [523, 659, 784, 1047].forEach((f, i) => beep(f, 0.18, 'square', 0.05, i * 0.13)),
    lose: () => [300, 240, 180, 120].forEach((f, i) => beep(f, 0.3, 'sawtooth', 0.06, i * 0.18)),
  };
  function syncMute() { $('#mute').textContent = 'SOUND: ' + (muted ? 'OFF' : 'ON'); }
  $('#mute').addEventListener('click', () => {
    muted = !muted; syncMute();
    try { localStorage.setItem('esr_muted', muted ? '1' : '0'); } catch (e) { }
    sfx.click();
  });
  syncMute();

  async function request(method, path, body) {
    const res = await fetch('/api/' + path, {
      method, headers: { 'Content-Type': 'application/json' },
      body: method === 'POST' ? JSON.stringify(body || {}) : undefined,
    });
    return res.json();
  }
  async function act(path, body) {
    if (busy) return;
    busy = true;
    try { handle(await request('POST', path, body)); }
    catch (e) { toast('Connection problem. Is the server still running?'); }
    finally { busy = false; }
  }
  function handle(r) {
    if (r.error) {
      toast(r.error);
      if (r.state && r.state.phase !== S.phase) render(r.state, {});
      return;
    }
    render(r.state, r.result || {});
  }

  let toastTimer = null;
  function toast(msg, good) {
    const t = $('#toast');
    t.textContent = msg; t.className = 'toast' + (good ? ' good' : ''); t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 2600);
  }
  function flash(cls, ms) {
    document.body.classList.remove('flash-ok', 'flash-bad', 'flash-gold', 'shake');
    void document.body.offsetWidth;
    document.body.classList.add(...cls);
    setTimeout(() => document.body.classList.remove(...cls), ms || 700);
  }
  function applyFx(result) {
    switch (result.fx) {
      case 'correct': flash(['flash-ok'], 600); sfx.correct(); break;
      case 'wrong': flash(['flash-bad', 'shake'], 700); sfx.wrong(); break;
      case 'vault_reset': flash(['flash-bad', 'shake'], 700); sfx.wrong(); toast(result.message); break;
      case 'vault_miss': sfx.click(); toast(result.message, true); break;
      case 'hint': case 'powerup': sfx.power(); if (result.message) toast(result.message, true); break;
      case 'click': sfx.click(); break;
      case 'god': flash(['flash-gold'], 800); sfx.win(); toast('GOD MODE ENABLED', true); break;
      default: break;
    }
  }

  function typeInto(el, text, speed) {
    const my = ++typeToken; let i = 0;
    el.textContent = ''; el.classList.add('typing');
    const finish = () => { el.textContent = text; el.classList.remove('typing'); };
    (function step() {
      if (my !== typeToken) return;
      i += 1; el.textContent = text.slice(0, i);
      if (i < text.length) setTimeout(step, speed || 14); else el.classList.remove('typing');
    })();
    el.onclick = () => { if (my === typeToken) { typeToken++; finish(); } };
  }
  function warden(text, speed, who, cls) {
    const txt = h('div', { class: 'txt' });
    const box = h('div', { class: 'warden' + (cls ? ' ' + cls : '') }, h('div', { class: 'who', text: who || 'WARDEN' }), txt);
    typeInto(txt, text, speed);
    return box;
  }

  function confetti(ms) {
    const c = $('#confetti'), ctx = c.getContext('2d');
    c.width = innerWidth; c.height = innerHeight;
    const colors = ['#39ff88', '#3dd9ff', '#ffc542', '#ff4d5e', '#ffffff'];
    const bits = Array.from({ length: 140 }, () => ({
      x: Math.random() * c.width, y: -Math.random() * c.height * 0.6, s: 4 + Math.random() * 6,
      vx: -1.5 + Math.random() * 3, vy: 2 + Math.random() * 4, col: colors[Math.floor(Math.random() * colors.length)]
    }));
    const t0 = performance.now();
    (function frame(t) {
      ctx.clearRect(0, 0, c.width, c.height);
      bits.forEach(b => { b.x += b.vx; b.y += b.vy; ctx.fillStyle = b.col; ctx.fillRect(b.x, b.y, b.s, b.s * 0.6); });
      if (t - t0 < (ms || 3500)) requestAnimationFrame(frame); else ctx.clearRect(0, 0, c.width, c.height);
    })(t0);
  }

  const fmt = (sec) => { sec = Math.max(0, Math.ceil(sec)); return String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0'); };

  function updateHud(hud, phase) {
    const el = $('#hud');
    if (!hud || phase === 'menu') {
      el.hidden = true;
      timer.running = false;
      godOn = false;
      document.body.classList.remove('god');
      return;
    }
    el.hidden = false;
    godOn = !!hud.god;
    document.body.classList.toggle('god', godOn);
    $('#lives').replaceChildren(...(godOn
      ? [h('span', { text: '\u221E' })]
      : Array.from({ length: hud.max_lives }, (_, i) => h('span', { class: i < hud.lives ? '' : 'empty', text: i < hud.lives ? '\u2665' : '\u2661' }))));
    $('#chips').replaceChildren(...Array.from({ length: 5 }, (_, i) => h('span', { class: i < hud.chips ? '' : 'empty', text: i < hud.chips ? '\u25C6' : '\u25C7' })));
    $('#score').textContent = hud.score;
    $('#streak').textContent = hud.streak + (hud.mult > 1 ? ' (x' + hud.mult + ')' : '');
    timer.end = performance.now() + hud.remaining * 1000;
    timer.total = hud.total; timer.running = hud.running && !godOn;
    $('#timer').textContent = godOn ? '\u221E' : fmt(hud.remaining);
    $('#timer-fill').style.width = Math.min(100, hud.remaining / hud.total * 100) + '%';
    el.classList.toggle('danger', hud.running && !godOn && hud.remaining < 60);

    const inv = $('#inventory');
    const active = phase !== 'intro' && phase !== 'end';
    const labels = { battery: ['BATTERY', '+1 life'], filter: ['FILTER', 'removes 2 wrong choices'], pause: ['PAUSE', '+60 seconds'] };
    inv.replaceChildren(
      h('span', { class: 'label', text: 'POWER-UPS' }),
      ...Object.keys(labels).map(k => h('button', {
        class: 'pu', title: hud.lock_powerups ? 'Stuck in the web!' : labels[k][1], disabled: !(active && hud.inventory[k] > 0) || hud.lock_powerups,
        onclick: () => act('powerup', { item: k })
      }, labels[k][0] + ' ', h('b', { text: 'x' + hud.inventory[k] }))),
      hud.double_next ? h('span', { class: 'double-badge', text: 'NEXT ANSWER = DOUBLE POINTS' }) : null,
      godOn ? h('span', { class: 'god-badge', text: 'GOD MODE' }) : null
    );
  }

  function updateQBar(left) {
    const fill = $('#qfill');
    const label = $('#qlabel');
    if (!fill) return;
    const frac = Math.max(0, Math.min(1, left / qtimer.limit));
    const crit = qtimer.limit - left <= qtimer.crit;
    fill.style.width = (frac * 100) + '%';
    fill.className = 'qfill' + (crit ? ' crit' : (left < 5 ? ' low' : ''));
    label.textContent = Math.ceil(left) + 's' + (crit ? '   CRIT ZONE: DOUBLE DAMAGE' : '');
  }

  function questionTimeUp() {
    timeupBusy = true;
    request('POST', 'timeup', {}).then((r) => {
      if (r.error) {
        if (r.error === 'Not yet.') qtimer.end = performance.now() + 300;
        else if (r.state) handle(r);
      } else {
        handle(r);
      }
    }).catch(() => {}).finally(() => { timeupBusy = false; });
  }

  setInterval(() => {
    if (qtimer.on) {
      const left = Math.max(0, (qtimer.end - performance.now()) / 1000);
      updateQBar(left);
      if (left <= 0 && !timeupBusy) questionTimeUp();
    }
    if (!timer.running) return;
    const left = Math.max(0, (timer.end - performance.now()) / 1000);
    $('#timer').textContent = fmt(left);
    $('#timer-fill').style.width = Math.min(100, left / timer.total * 100) + '%';
    $('#hud').classList.toggle('danger', left < 60);
    const sec = Math.ceil(left);
    if (left > 0 && left <= 10 && sec !== lastSecond) { lastSecond = sec; sfx.tick(); }
    if (left <= 0 && !syncing) {
      syncing = true;
      request('GET', 'state').then(handle).catch(() => {}).finally(() => { syncing = false; });
    }
  }, 250);

  const screens = {};

  const DIFFS = {
    easy: ['EASY', '8 lives | 20s per question', 'simple fights'],
    normal: ['NORMAL', '6 lives | 15s per question', 'enemy tricks sometimes'],
    hard: ['HARD', '4 lives | 12s per question', 'enemy tricks often'],
  };

  screens.menu = () => {
    let saved = '';
    try { saved = localStorage.getItem('esr_name') || ''; } catch (e) { }
    const name = h('input', { type: 'text', maxlength: '12', placeholder: 'Enter your name', autocomplete: 'off', 'aria-label': 'Your name' });
    name.value = saved;
    const diffBox = h('div', { class: 'diff' });
    const drawDiff = () => diffBox.replaceChildren(...Object.keys(DIFFS).map(k => h('button', {
      class: k === selectedDiff ? 'sel' : '', type: 'button',
      onclick: () => { selectedDiff = k; sfx.click(); drawDiff(); }
    }, h('b', { text: DIFFS[k][0] }), h('span', { text: DIFFS[k][1] }), h('span', { text: DIFFS[k][2] }))));
    drawDiff();

    const start = () => {
      const n = name.value.trim() || 'PLAYER';
      try { localStorage.setItem('esr_name', n); } catch (e) { }
      sfx.click();
      act('start', { name: n, difficulty: selectedDiff }).then(() => {
        if (godArmed) {
          godArmed = false;
          act('god');
        }
      });
    };
    name.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); start(); } });
    const board = h('div', { class: 'panel' }, h('h3', { text: 'TOP 5 ESCAPE ARTISTS' }), h('div', { class: 'dim', text: 'Loading...' }));

    const rack = [
      '  \u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557',
      '  \u2551 \u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593  \u25CF \u25CF \u25CB \u2551',
      '  \u2551 \u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593  \u25CB \u25CF \u25CF \u2551',
      '  \u2551 \u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593\u2593  \u25CF \u25CB \u25CF \u2551',
      '  \u255A\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255D'].join('\n');

    screen.replaceChildren(
      h('div', { class: 'panel center' },
        h('pre', { class: 'banner', text: rack }),
        h('h1', { class: 'glitch', text: 'ESCAPE THE SERVER ROOM' }),
        h('p', { class: 'tagline', text: 'Solve five rooms of IT puzzles before WARDEN purges the servers.' })),
      h('div', { class: 'panel' },
        h('h3', { text: 'AGENT NAME' }), name,
        h('h3', { text: 'DIFFICULTY', style: 'margin-top:18px' }), diffBox,
        h('button', { class: 'btn', id: 'primary', onclick: start, text: 'START MISSION' })),
      h('div', { class: 'panel' },
        h('h3', { text: 'HOW TO PLAY' }),
        h('p', { class: 'dim', text: 'Beat four Guardians, then face WARDEN. Every correct answer hurts the enemy, and a very fast answer is a CRITICAL HIT for double damage. Wrong answers and slow ones cost a life. Collect gifts, beat the purge timer, and decide the fate of WARDEN.' })),
      board);
    request('GET', 'highscores').then(list => renderBoard(board, list)).catch(() => {});
  };

  function renderBoard(box, list) {
    box.replaceChildren(h('h3', { text: 'TOP 5 ESCAPE ARTISTS' }));
    if (!list.length) { box.append(h('div', { class: 'dim', text: 'No scores yet. Be the first!' })); return; }
    box.append(h('table', {},
      h('tr', {}, ...['#', 'NAME', 'SCORE', 'RANK', 'LEVEL', 'RESULT'].map(t => h('th', { text: t }))),
      ...list.map((s, i) => h('tr', {}, ...[i + 1, s.name, s.score, s.rank, s.difficulty, s.result].map(v => h('td', { text: String(v) }))))));
  }

  screens.intro = (st) => {
    screen.replaceChildren(h('div', { class: 'panel' },
      h('h2', { text: 'MISSION BRIEFING' }),
      warden(st.story, 12),
      h('p', { class: 'dim', text: 'The purge timer starts when you press BEGIN.' }),
      h('button', { class: 'btn', id: 'primary', text: 'BEGIN MISSION', onclick: () => act('next') })));
  };

  screens.room_intro = (st) => {
    const r = st.room;
    const boss = r.index === 4;
    screen.replaceChildren(h('div', { class: 'panel' },
      h('div', { class: 'qmeta' }, h('span', { text: 'ROOM ' + (r.index + 1) + ' OF 5' }), h('span', { text: r.topic.toUpperCase() })),
      h('h2', { text: r.name.toUpperCase() }),
      h('p', { class: 'dim', text: r.intro }),
      h('div', { class: 'enemy-name', text: (boss ? 'FINAL BOSS: ' : 'GUARDIAN: ') + r.enemy.toUpperCase() }),
      warden(r.enemy_line, 16, boss ? 'WARDEN' : r.short, boss ? '' : 'minion'),
      r.warden_line ? h('div', { class: 'warden intercom' }, h('div', { class: 'who', text: 'WARDEN (INTERCOM)' }), h('div', { class: 'txt', text: r.warden_line })) : null,
      h('button', { class: 'btn', id: 'primary', text: boss ? 'FACE WARDEN' : 'FIGHT!', onclick: () => act('next') })));
  };

  screens.question = (st) => {
    const q = st.question;
    const hud = st.hud;
    if (q.id !== lastQId) { pendingText = ''; lastQId = q.id; }
    let hintLabel = 'HINT (FREE)';
    if (q.hint) hintLabel = 'HINT USED';
    else if (q.hint_locked) hintLabel = 'HINT LOCKED';
    else if (hud.god) hintLabel = 'SHOW ANSWER (FREE)';
    else if (hud.hint_cost) hintLabel = 'HINT (-' + hud.hint_cost + ' pts)';
    const hintBtn = h('button', {
      class: 'btn ghost small', type: 'button', disabled: !!q.hint || q.hint_locked, text: hintLabel, onclick: () => act('hint')
    });
    const bar = q.time_limit
      ? h('div', { class: 'qwrap' },
        h('div', { class: 'qbar' },
          h('div', { class: 'qcrit', style: 'left:' + ((q.time_limit - q.crit_window) / q.time_limit * 100) + '%' }),
          h('div', { class: 'qfill', id: 'qfill' })),
        h('div', { class: 'qlabel', id: 'qlabel', text: '' }))
      : h('div', { class: 'dim', text: 'NO TIMER (GOD MODE)' });
    const panel = h('div', { class: 'panel' },
      h('div', { class: 'qmeta' }, h('span', { text: q.room.toUpperCase() }), h('span', { text: q.enemy + '  HP ' + hud.enemy_hp + '/' + hud.enemy_max })),
      q.ability ? h('div', { class: 'ability' }, h('b', { text: q.ability.title }), ' ' + q.ability.text) : null,
      bar,
      h('div', { class: 'qtext', text: q.text }),
      q.code ? h('pre', { class: 'code', text: q.code }) : null);

    if (q.type === 'mc') {
      panel.append(h('div', { class: 'options' }, ...q.options.map((o, i) =>
        h('button', { class: 'opt', onclick: () => act('answer', { answer: o }) }, h('span', { class: 'k', text: '[' + (i + 1) + ']' }), o))));
    } else {
      const input = h('input', { type: 'text', autocomplete: 'off', placeholder: 'Type your answer and press Enter', 'aria-label': 'Your answer' });
      input.value = pendingText;
      input.addEventListener('input', () => { pendingText = input.value; });
      const form = h('form', { class: 'row', style: 'margin-top:14px;flex-wrap:nowrap', onsubmit: (e) => { e.preventDefault(); act('answer', { answer: input.value }); } },
        input, h('button', { class: 'btn', type: 'submit', text: 'SUBMIT' }));
      panel.append(form);
      setTimeout(() => input.focus(), 50);
    }
    panel.append(h('div', { style: 'margin-top:16px' }, hintBtn));
    if (q.hint) panel.append(h('div', { class: 'hintbox', text: 'HINT: ' + q.hint }));
    screen.replaceChildren(panel);
    if (q.time_limit) {
      qtimer = { on: true, end: performance.now() + q.time_left * 1000, limit: q.time_limit, crit: q.crit_window };
      updateQBar(q.time_left);
    }
  };

  screens.feedback = (st) => {
    const f = st.feedback;
    const panel = h('div', { class: 'panel' });
    if (f.correct) {
      const parts = [f.damage + ' damage' + (f.crit ? ' (CRIT)' : '')];
      if (f.mult > 1) parts.push('x' + f.mult + ' streak');
      if (f.double) parts.push('x2 glitch');
      panel.append(h('div', { class: f.crit ? 'banner-ok crit' : 'banner-ok', text: f.crit ? 'CRITICAL HIT!' : 'ACCESS GRANTED' }),
        h('div', { class: 'points', text: '+' + f.points + ' points  (' + parts.join(', ') + ')' }));
    } else {
      panel.append(h('div', { class: 'banner-bad', text: f.reason === 'time' ? "TIME'S UP!" : 'ACCESS DENIED' }),
        h('div', { class: 'points', text: (st.hud.god ? 'No life lost.' : '-1 life.') + '   Correct answer: ' + f.correct_answer }));
    }
    let nextLabel = 'NEXT';
    if (f.defeated) nextLabel = st.hud.room === 4 ? 'TO THE ROOT CONSOLE' : 'CONTINUE';
    panel.append(warden(f.message, 12),
      f.defeated ? h('div', { class: 'points', text: 'ENEMY DEFEATED!' }) : null,
      h('div', { class: 'explain', text: f.explain }),
      h('div', { style: 'margin-top:18px' }, h('button', { class: 'btn', id: 'primary', text: nextLabel, onclick: () => act('next') })));
    screen.replaceChildren(panel);
  };

  screens.vault = (st) => {
    const v = st.vault;
    const digits = Array.from({ length: v.length }, () => h('div', { class: 'digit', text: '_' }));
    const input = h('input', { type: 'text', inputmode: 'numeric', maxlength: String(v.length), autocomplete: 'off', placeholder: 'Type ' + v.length + ' digits', 'aria-label': 'Vault code' });
    input.addEventListener('input', () => {
      input.value = input.value.replace(/\D/g, '').slice(0, v.length);
      digits.forEach((d, i) => { d.textContent = input.value[i] || '_'; });
    });
    const form = h('form', { class: 'row', style: 'flex-wrap:nowrap', onsubmit: (e) => { e.preventDefault(); act('vault', { guess: input.value }); } },
      input, h('button', { class: 'btn', type: 'submit', text: 'ENTER' }));
    const hintBtn = h('button', {
      class: 'btn ghost small', type: 'button', disabled: v.hint_used,
      text: v.hint_used ? 'HINT USED' : (st.hud.hint_cost ? 'REVEAL A DIGIT (-' + st.hud.hint_cost + ' pts)' : 'SHOW THE CODE (FREE)'), onclick: () => act('hint')
    });
    const rows = v.history.map(g => h('div', { class: 'guess' },
      h('span', { class: 'digits', text: g.guess }),
      h('span', {}, ...Array.from({ length: g.exact }, () => h('span', { class: 'peg g' })), ...Array.from({ length: g.misplaced }, () => h('span', { class: 'peg a' }))),
      h('span', { class: 'fb', text: g.exact + ' right place, ' + g.misplaced + ' wrong place' })));

    screen.replaceChildren(h('div', { class: 'panel' },
      h('div', { class: 'qmeta' }, h('span', { text: 'FINAL STEP' }), h('span', { text: v.tries_left + ' / ' + v.max_tries + ' TRIES LEFT' })),
      h('h2', { text: 'ROOT CONSOLE' }),
      h('p', { text: v.text }),
      h('p', { class: 'dim', text: 'Crack the secret 4-digit code. Green = right digit, right place. Amber = right digit, wrong place. The secret never repeats a digit. Run out of tries and you lose a life and face a new code.' }),
      h('div', { class: 'keys' }, ...digits), form,
      h('div', { class: 'guesses' }, ...rows),
      h('div', {}, hintBtn),
      v.hint ? h('div', { class: 'hintbox', text: 'HINT: ' + v.hint }) : null));
    setTimeout(() => input.focus(), 50);
  };

  screens.room_clear = (st) => {
    const c = st.clear;
    screen.replaceChildren(h('div', { class: 'panel center' },
      h('h2', { text: c.enemy.toUpperCase() + ' DEBUGGED!' }),
      warden(c.defeat, 14, c.enemy.toUpperCase(), 'minion'),
      h('p', { text: c.chip + ' collected.' }),
      h('p', { class: 'points', text: 'Gift: ' + c.gift + '.' }),
      c.healed ? h('p', { class: 'points', text: '+1 life restored.' }) : null,
      c.flawless ? h('p', { class: 'points', text: 'Flawless! +100 bonus points.' }) : null,
      h('div', { class: 'logbox' }, h('div', { class: 'label', text: 'RECOVERED LOG FILE' }), h('div', { text: c.log })),
      h('div', { class: 'event' }, h('h3', { text: c.event.title }), h('div', { text: c.event.text })),
      h('div', { style: 'margin-top:18px' }, h('button', { class: 'btn', id: 'primary', text: 'NEXT ROOM', onclick: () => act('next') }))));
  };

  screens.choice = (st) => {
    screen.replaceChildren(h('div', { class: 'panel center' },
      h('h2', { text: 'ROOT CONSOLE' }),
      h('p', { text: st.choice.text }),
      h('div', { class: 'choices' },
        h('button', { class: 'btn choice del', onclick: () => act('choose', { choice: 'delete' }) },
          h('b', { text: 'DELETE WARDEN' }), h('span', { text: 'End him for good. The old system is gone.' })),
        h('button', { class: 'btn choice patch', onclick: () => act('choose', { choice: 'patch' }) },
          h('b', { text: 'PATCH WARDEN' }), h('span', { text: 'Fix his bug. Make him your ally.' })))));
  };

  screens.end = (st, fresh) => {
    const e = st.end;
    const cls = e.ending === 'patch' ? 'end-secret' : e.escaped ? 'end-win' : 'end-lose';
    const review = h('div', { hidden: true });
    e.review.forEach(r => review.append(h('div', { class: 'review-item' },
      h('div', { class: 'dim', text: r.room }),
      h('div', { text: r.question }),
      r.code ? h('pre', { class: 'code', text: r.code }) : null,
      h('div', {}, h('span', { class: 'wrong', text: 'You: ' + r.yours }), '   ', h('span', { class: 'right', text: 'Answer: ' + r.correct })),
      h('div', { class: 'dim', text: r.explain }))));
    const reviewBtn = h('button', {
      class: 'btn ghost', disabled: !e.review.length, text: e.review.length ? 'REVIEW MISSED (' + e.review.length + ')' : 'NOTHING TO REVIEW',
      onclick: () => { review.hidden = !review.hidden; }
    });
    const board = h('div', { class: 'panel' });
    renderBoard(board, e.highscores);

    screen.replaceChildren(
      h('div', { class: 'panel center' },
        h('h1', { class: cls, style: 'font-size:34px', text: e.title }),
        warden(e.message, 14),
        h('div', { class: 'rankbadge', text: 'RANK: ' + e.rank.toUpperCase() }),
        h('div', { class: 'stats' },
          h('div', { class: 'stat' }, h('b', { text: String(e.score) }), 'FINAL SCORE'),
          h('div', { class: 'stat' }, h('b', { text: e.chips + ' / 5' }), 'CHIPS'),
          h('div', { class: 'stat' }, h('b', { text: String(e.lives_lost) }), 'LIVES LOST'),
          h('div', { class: 'stat' }, h('b', { text: String(e.best_streak) }), 'BEST STREAK'),
          h('div', { class: 'stat' }, h('b', { text: '+' + e.time_bonus }), 'TIME BONUS'),
          e.flawless_bonus ? h('div', { class: 'stat' }, h('b', { text: '+' + e.flawless_bonus }), 'FLAWLESS BONUS') : null),
        h('div', { class: 'row', style: 'justify-content:center' },
          h('button', { class: 'btn', id: 'primary', text: 'PLAY AGAIN', onclick: () => { sfx.click(); render({ phase: 'menu' }, {}); } }),
          reviewBtn),
        st.hud && st.hud.god ? h('p', { class: 'dim', text: 'God mode runs are not saved to the leaderboard.' }) : null),
      h('div', { class: 'panel' }, h('h3', { text: 'REVIEW MODE' }), h('div', { class: 'dim', text: 'Questions you missed, with the right answers:' }), review),
      board);
    if (fresh) {
      if (e.escaped) { sfx.win(); confetti(e.ending === 'patch' ? 6000 : 3500); } else sfx.lose();
    }
  };

  function render(state, result) {
    const prevPhase = S.phase;
    S = state;
    qtimer.on = false;
    applyFx(result || {});
    updateHud(state.hud, state.phase);
    Battle.sync(state, result || {});
    typeToken++;
    if (state.phase === 'menu') { $('#hud').hidden = true; screens.menu(); }
    else if (state.phase === 'end') screens.end(state, prevPhase !== 'end');
    else (screens[state.phase] || screens.menu)(state);
    window.scrollTo({ top: 0 });
  }

  function triggerGod() {
    if (godOn) return;
    if (S.phase === 'menu') {
      if (!godArmed) {
        godArmed = true;
        sfx.power();
        toast('CHEAT CODE ACCEPTED', true);
      }
    } else if (S.phase !== 'end') {
      act('god');
    }
  }

  document.addEventListener('keydown', (e) => {
    if (e.target.tagName !== 'INPUT') {
      const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
      konamiAt = key === KONAMI[konamiAt] ? konamiAt + 1 : (key === KONAMI[0] ? 1 : 0);
      if (konamiAt === KONAMI.length) {
        konamiAt = 0;
        triggerGod();
      }
    }
    if (e.target.tagName === 'INPUT' || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === 'Enter') {
      const b = document.getElementById('primary');
      if (b && !b.disabled) { e.preventDefault(); b.click(); }
    } else if (/^[1-4]$/.test(e.key)) {
      const opts = document.querySelectorAll('.opt');
      const b = opts[Number(e.key) - 1];
      if (b) b.click();
    }
  });

  request('GET', 'state').then(handle).catch(() => render({ phase: 'menu' }, {}));
})();
