Check that Python is installed. Open Command Prompt (press the Windows key, type cmd, press Enter) and run python --version. If you get an error, install Python from python.org and tick “Add Python to PATH” during setup.
Unzip the folder. Right-click escape_the_server_room.zip and choose Extract All. Don’t run it from inside the zip.
Open a terminal inside the folder. Open the extracted folder in File Explorer, click the address bar, type cmd and press Enter. In VS Code you can use File > Open Folder, then Terminal > New Terminal.
Install Flask (once only). Run pip install -r requirements.txt.
Start the game. Run python app.py. You should see a line saying it’s running on http://127.0.0.1:5000. Leave this window open, because closing it stops the game.
Play it in your browser. Open Chrome, Edge or Firefox, go to http://127.0.0.1:5000, type a name, pick a difficulty and press START MISSION.
Stop the game. Press Ctrl + C in the terminal window.