import os
import random
import time

from questions import ROOMS, QUESTION_BANK, LINES, ABILITIES


DIFFICULTY = {
    "easy":   {"lives": 8, "minutes": 20, "hint_cost": 15, "qtime": 20, "ability": 0.0},
    "normal": {"lives": 6, "minutes": 15, "hint_cost": 25, "qtime": 15, "ability": 0.3},
    "hard":   {"lives": 4, "minutes": 10, "hint_cost": 40, "qtime": 12, "ability": 0.5},
}
MINION_HP = 10
BOSS_HP = 15
BOSS_ROOM = 4
CRIT_DAMAGE = 2
POINTS_PER_HP = 100
CRIT_BONUS = 50
TEXT_EXTRA_TIME = 5
TIME_GRACE = 1.5
HEAL_ON_WIN = 1
VAULT_TRIES = 8
CODE_LENGTH = 4
PAUSE_SECONDS = 60
SURGE_SECONDS = 30
ROOM_CLEAR_BONUS = 100
FLAWLESS_BONUS = 500
HIGHSCORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscores.txt")


RANKS = [(14000, "Root Admin"), (12000, "Sysadmin"), (6000, "Technician"), (0, "Intern")]

POWERUPS = {
    "battery": {"label": "Backup Battery", "desc": "+1 life"},
    "filter":  {"label": "Firewall Filter", "desc": "removes 2 wrong choices"},
    "pause":   {"label": "Pause Purge", "desc": "+60 seconds"},
}

GIFTS = {
    "pause": "a Pause Purge",
    "filter": "a Firewall Filter",
    "battery": "a Backup Battery",
    "glitch": "a Glitch Charge: your next correct answer is worth double points",
}


class GameError(Exception):
    pass


def now():
    return time.time()


def norm(text):
    return " ".join(str(text).strip().lower().split())


def multiplier(streak):
    if streak >= 5:
        return 2.0
    if streak >= 3:
        return 1.5
    return 1.0


def rank_for(score):
    for minimum, title in RANKS:
        if score >= minimum:
            return title
    return "Intern"


def clean_name(name):
    name = str(name or "").replace("|", " ").replace("\n", " ").strip()
    return name[:12] or "PLAYER"


def remaining(g):
    if g["god"]:
        return 5999.0
    if g["deadline"] is None:
        return g["cfg"]["minutes"] * 60
    return max(0.0, g["deadline"] - now())


def check_time(g):
    if g["phase"] not in ("intro", "end") and remaining(g) <= 0:
        end_game(g, "time")


def new_game(name, difficulty):
    difficulty = difficulty if difficulty in DIFFICULTY else "normal"
    cfg = DIFFICULTY[difficulty]
    g = {
        "name": clean_name(name), "difficulty": difficulty, "cfg": cfg,
        "lives": cfg["lives"], "max_lives": cfg["lives"],
        "score": 0, "streak": 0, "best_streak": 0,
        "room": 0, "chips": 0, "asked": 0,
        "enemy_hp": MINION_HP, "enemy_max": MINION_HP, "pool": [], "last_q": None,
        "inventory": {"battery": 0, "filter": 0, "pause": 0},
        "deadline": None, "bonus_seconds": 0,
        "phase": "intro", "current": None, "feedback": None, "clear": None,
        "vault": None, "end": None, "missed": [],
        "lives_lost": 0, "room_lives_lost": 0, "double_next": False, "saved": False,
        "god": False,
    }
    start_fight(g)
    return g


def start_fight(g):
    g["enemy_max"] = BOSS_HP if g["room"] == BOSS_ROOM else MINION_HP
    g["enemy_hp"] = g["enemy_max"]
    g["room_lives_lost"] = 0
    g["pool"] = []
    g["last_q"] = None
    g["current"] = None


def room_bank(room):
    if room == BOSS_ROOM:
        return [q for r in range(BOSS_ROOM) for q in QUESTION_BANK[r]]
    return QUESTION_BANK[room]


def next_question(g):
    if not g["pool"]:
        g["pool"] = list(room_bank(g["room"]))
        random.shuffle(g["pool"])
        if len(g["pool"]) > 1 and g["pool"][-1] is g["last_q"]:
            g["pool"][0], g["pool"][-1] = g["pool"][-1], g["pool"][0]
    q = g["pool"].pop()
    g["last_q"] = q
    return q


def advance(g):
    check_time(g)
    phase = g["phase"]
    if phase == "intro":
        g["deadline"] = now() + g["cfg"]["minutes"] * 60
        g["phase"] = "room_intro"
    elif phase == "room_intro":
        set_question(g)
    elif phase == "feedback":
        if g["enemy_hp"] > 0:
            set_question(g)
        elif g["room"] == BOSS_ROOM:
            new_vault(g)
            g["phase"] = "vault"
        else:
            finish_room(g)
    elif phase == "room_clear":
        g["room"] += 1
        start_fight(g)
        g["phase"] = "room_intro"
    else:
        raise GameError("Nothing to advance right now.")
    return {"fx": "click"}


def pick_ability(g):
    chance = g["cfg"]["ability"]
    if g["god"] or chance <= 0:
        return None
    if g["room"] == BOSS_ROOM:
        key = random.choice(list(ABILITIES))
        chance = min(0.9, chance + 0.25)
        owner = "WARDEN"
    else:
        key = ROOMS[g["room"]]["ability"]
        owner = ROOMS[g["room"]]["short"]
    if random.random() >= chance:
        return None
    move, text = ABILITIES[key]
    return {"key": key, "title": "%s USES %s!" % (owner, move), "text": text}


def set_question(g):
    q = next_question(g)
    options = list(q["options"]) if q["type"] == "mc" else []
    random.shuffle(options)
    ability = pick_ability(g)
    limit = g["cfg"]["qtime"] + (TEXT_EXTRA_TIME if q["type"] == "text" else 0)
    if ability and ability["key"] == "growl":
        limit = max(6, limit - 4)
    crit_window = max(2, round(limit / 3))
    if g["god"]:
        limit = None
    g["asked"] += 1
    g["current"] = {"q": q, "options": options, "removed": [], "hint_used": False, "started": now(),
                    "limit": limit, "crit_window": crit_window, "ability": ability, "id": g["asked"]}
    g["phase"] = "question"


def is_text_correct(q, given):
    given = norm(given)
    accepted = [norm(a) for a in [q["answer"]] + q.get("accept", [])]
    if q.get("binary"):
        given = given.lstrip("0") or "0"
        accepted = [a.lstrip("0") or "0" for a in accepted]
    return given in accepted


def answer(g, given):
    check_time(g)
    if g["phase"] != "question":
        raise GameError("There is no question to answer.")
    cur = g["current"]
    q = cur["q"]
    elapsed = now() - cur["started"]
    if cur["limit"] and elapsed > cur["limit"] + TIME_GRACE:
        return miss(g, given, "time")
    if q["type"] == "mc":
        correct = (given == q["answer"]) and (given not in cur["removed"])
    else:
        correct = is_text_correct(q, given)
    if not correct:
        return miss(g, given, "wrong")

    ability = cur["ability"]
    crit = elapsed <= cur["crit_window"] and not (ability and ability["key"] == "static")
    damage = CRIT_DAMAGE if crit else 1
    g["enemy_hp"] = max(0, g["enemy_hp"] - damage)
    g["streak"] += 1
    g["best_streak"] = max(g["best_streak"], g["streak"])
    mult = multiplier(g["streak"])
    points = round((POINTS_PER_HP * damage + (CRIT_BONUS if crit else 0)) * mult)
    double = g["double_next"]
    if double:
        points *= 2
        g["double_next"] = False
    g["score"] += points
    g["feedback"] = {"correct": True, "points": points, "crit": crit, "damage": damage, "mult": mult,
                     "double": double, "explain": q["explain"], "defeated": g["enemy_hp"] <= 0,
                     "message": random.choice(LINES["crit" if crit else "correct"])}
    g["phase"] = "feedback"
    return {"fx": "correct", "damage": damage, "crit": crit}


def miss(g, given, reason):
    q = g["current"]["q"]
    g["streak"] = 0
    if not g["god"]:
        g["lives"] -= 1
        g["lives_lost"] += 1
        g["room_lives_lost"] += 1
    if reason == "time":
        yours = "(time ran out)"
    else:
        yours = str(given) if str(given).strip() else "(no answer)"
    g["missed"].append({"room": ROOMS[g["room"]]["name"], "question": q["q"], "code": q["code"],
                        "yours": yours, "correct": q["answer"], "explain": q["explain"]})
    g["feedback"] = {"correct": False, "reason": reason, "correct_answer": q["answer"], "explain": q["explain"],
                     "message": random.choice(LINES["timeout" if reason == "time" else "wrong"])}
    if g["lives"] <= 0:
        end_game(g, "lives")
    else:
        g["phase"] = "feedback"
    return {"fx": "wrong", "timeout": reason == "time"}


def question_timeout(g):
    check_time(g)
    if g["phase"] != "question":
        raise GameError("There is no question to time out.")
    cur = g["current"]
    if not cur["limit"]:
        raise GameError("This question has no timer.")
    if now() - cur["started"] < cur["limit"] - 0.5:
        raise GameError("Not yet.")
    return miss(g, "", "time")


def active_ability(g):
    cur = g["current"]
    if g["phase"] == "question" and cur and cur["ability"]:
        return cur["ability"]["key"]
    return None


def use_hint(g):
    check_time(g)
    if g["phase"] not in ("question", "vault"):
        raise GameError("No hint is needed right now.")
    cost = 0 if g["god"] else g["cfg"]["hint_cost"]
    if g["phase"] == "question":
        cur = g["current"]
        if active_ability(g) == "lockdown":
            raise GameError("Lockdown! Hints are locked this turn.")
        if cur["hint_used"]:
            raise GameError("You already used the hint for this question.")
        cur["hint_used"] = True
    else:
        v = g["vault"]
        if v["hint_used"]:
            raise GameError("You already used the hint for this code.")
        v["hint_used"] = True
        if g["god"]:
            v["revealed"] = "The code is %s." % v["secret"]
        else:
            position = random.randrange(CODE_LENGTH)
            v["revealed"] = "Digit %d of the code is %s." % (position + 1, v["secret"][position])
    g["score"] = max(0, g["score"] - cost)
    return {"fx": "hint", "message": random.choice(LINES["hint"])}


def use_powerup(g, item):
    check_time(g)
    if item not in POWERUPS:
        raise GameError("Unknown power-up.")
    if g["phase"] in ("intro", "end"):
        raise GameError("You cannot use that right now.")
    if active_ability(g) == "web":
        raise GameError("Stuck in the web! Power-ups are locked this turn.")
    if g["inventory"][item] <= 0:
        raise GameError("You do not have that power-up.")

    if item == "battery":
        if g["lives"] >= g["max_lives"]:
            raise GameError("Your lives are already full.")
        g["lives"] += 1
    elif item == "filter":
        cur = g["current"]
        if g["phase"] != "question" or cur["q"]["type"] != "mc":
            raise GameError("The Firewall Filter only works on multiple-choice questions.")
        if cur["removed"]:
            raise GameError("The filter is already active on this question.")
        wrong = [o for o in cur["options"] if o != cur["q"]["answer"]]
        cur["removed"] = random.sample(wrong, 2)
    elif item == "pause":
        if g["deadline"] is not None:
            g["deadline"] += PAUSE_SECONDS
        g["bonus_seconds"] += PAUSE_SECONDS
    g["inventory"][item] -= 1
    return {"fx": "powerup", "message": random.choice(LINES["powerup"])}


def give_random_powerup(g):
    item = random.choice(list(POWERUPS))
    g["inventory"][item] += 1
    return item


def finish_room(g):
    room = ROOMS[g["room"]]
    g["chips"] += 1
    flawless = g["room_lives_lost"] == 0
    info = {"chip": room["chip"], "enemy": room["enemy"], "flawless": flawless, "bonus": 0, "defeat": room["defeat"],
            "log": room["log"], "gift": GIFTS[room["gift"]], "healed": False}
    if flawless:
        g["score"] += ROOM_CLEAR_BONUS
        info["bonus"] = ROOM_CLEAR_BONUS
    if room["gift"] == "glitch":
        g["double_next"] = True
    else:
        g["inventory"][room["gift"]] += 1
    if g["lives"] < g["max_lives"]:
        g["lives"] += HEAL_ON_WIN
        info["healed"] = True

    event = random.choice(["surge", "lucky", "glitch", "calm"])
    if event == "surge":
        if g["deadline"] is not None:
            g["deadline"] -= SURGE_SECONDS
        info["event"] = {"title": "POWER SURGE", "text": "A surge fries the clock. You lose 30 seconds."}
    elif event == "lucky":
        item = POWERUPS[give_random_powerup(g)]["label"]
        info["event"] = {"title": "LUCKY FIND", "text": "You find a %s lying under a server rack." % item}
    elif event == "glitch":
        g["double_next"] = True
        info["event"] = {"title": "WARDEN GLITCH", "text": "WARDEN glitches! Your next correct answer is worth DOUBLE points."}
    else:
        info["event"] = {"title": "QUIET MOMENT", "text": LINES["event_calm"]}
    g["clear"] = info
    g["phase"] = "room_clear"
    check_time(g)


def new_vault(g):
    g["vault"] = {"secret": "".join(random.sample("0123456789", CODE_LENGTH)),
                  "tries_left": VAULT_TRIES, "history": [], "hint_used": False, "revealed": None}


def vault_guess(g, guess):
    check_time(g)
    if g["phase"] != "vault":
        raise GameError("The vault is not active.")
    guess = str(guess).strip()
    if len(guess) != CODE_LENGTH or not guess.isdigit():
        raise GameError("Enter exactly %d digits." % CODE_LENGTH)
    v = g["vault"]
    secret = v["secret"]
    exact = sum(1 for a, b in zip(guess, secret) if a == b)
    common = sum(min(guess.count(d), secret.count(d)) for d in set(guess))
    v["history"].append({"guess": guess, "exact": exact, "misplaced": common - exact})
    v["tries_left"] -= 1

    if exact == CODE_LENGTH:
        g["score"] += 200 + 25 * v["tries_left"]
        g["chips"] += 1
        if g["room_lives_lost"] == 0:
            g["score"] += ROOM_CLEAR_BONUS
        g["phase"] = "choice"
        return {"fx": "vault_win"}

    if v["tries_left"] <= 0:
        if not g["god"]:
            g["lives"] -= 1
            g["lives_lost"] += 1
            g["room_lives_lost"] += 1
        g["streak"] = 0
        g["missed"].append({"room": "The Vault", "question": "Crack the 4-digit code", "code": None,
                            "yours": "(ran out of tries)", "correct": secret,
                            "explain": "Use the feedback: green means right digit in the right place, amber means right digit in the wrong place."})
        if g["lives"] <= 0:
            end_game(g, "lives")
            return {"fx": "wrong"}
        new_vault(g)
        return {"fx": "vault_reset", "message": "Out of tries! The vault resets with a NEW code. You lose a life."}
    return {"fx": "vault_miss", "message": random.choice(LINES["vault_close"])}


def choose(g, choice):
    check_time(g)
    if g["phase"] != "choice":
        raise GameError("There is nothing to choose right now.")
    if choice not in ("delete", "patch"):
        raise GameError("Choose DELETE or PATCH.")
    end_game(g, choice)
    return {"fx": choice}


def end_game(g, ending):
    if g["phase"] == "end":
        return
    escaped = ending in ("delete", "patch")
    time_bonus = 0
    flawless_bonus = 0
    if escaped and not g["god"]:
        time_bonus = int(remaining(g))
        if g["lives_lost"] == 0:
            flawless_bonus = FLAWLESS_BONUS
    g["score"] += time_bonus + flawless_bonus
    g["phase"] = "end"
    titles = {"delete": "YOU ESCAPED!", "patch": "WARDEN PATCHED!",
              "time": "SYSTEM PURGED", "lives": "SYSTEM FAILURE"}
    g["end"] = {"ending": ending, "title": titles[ending], "message": LINES[ending],
                "score": g["score"], "rank": rank_for(g["score"]), "time_bonus": time_bonus,
                "flawless_bonus": flawless_bonus, "chips": g["chips"], "lives_lost": g["lives_lost"],
                "best_streak": g["best_streak"], "escaped": escaped}
    if not g["saved"]:
        g["saved"] = True
        if not g["god"]:
            save_score(g)
    g["end"]["highscores"] = load_scores()


def load_scores():
    scores = []
    try:
        with open(HIGHSCORE_FILE, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) == 5:
                    try:
                        scores.append({"name": parts[0], "score": int(parts[1]), "rank": parts[2],
                                       "difficulty": parts[3], "result": parts[4]})
                    except ValueError:
                        continue
    except FileNotFoundError:
        pass
    scores.sort(key=lambda s: s["score"], reverse=True)
    return scores[:5]


def save_score(g):
    top = load_scores()
    top.append({"name": g["name"], "score": g["score"], "rank": rank_for(g["score"]),
                "difficulty": g["difficulty"],
                "result": "Escaped" if g["end"]["escaped"] else "Failed"})
    top.sort(key=lambda s: s["score"], reverse=True)
    try:
        with open(HIGHSCORE_FILE, "w", encoding="utf-8") as f:
            for s in top[:5]:
                f.write("%s|%d|%s|%s|%s\n" % (s["name"], s["score"], s["rank"], s["difficulty"], s["result"]))
    except OSError:
        pass


def activate_god(g):
    if g["phase"] == "end":
        raise GameError("The game is already over.")
    g["god"] = True
    cur = g["current"]
    if cur:
        cur["limit"] = None
        cur["ability"] = None
    return {"fx": "god"}


def view(g):
    check_time(g)
    phase = g["phase"]
    ability = active_ability(g)
    out = {
        "phase": phase,
        "hud": {"name": g["name"], "difficulty": g["difficulty"], "lives": g["lives"],
                "max_lives": g["max_lives"], "score": g["score"], "streak": g["streak"],
                "mult": multiplier(g["streak"]), "remaining": round(remaining(g), 1),
                "total": g["cfg"]["minutes"] * 60 + g["bonus_seconds"],
                "running": phase not in ("intro", "end"), "room": g["room"], "chips": g["chips"],
                "inventory": g["inventory"], "double_next": g["double_next"],
                "hint_cost": 0 if g["god"] else g["cfg"]["hint_cost"],
                "god": g["god"], "enemy_hp": g["enemy_hp"], "enemy_max": g["enemy_max"],
                "lock_powerups": ability == "web"},
    }
    if phase == "intro":
        out["story"] = LINES["story"]
    elif phase == "room_intro":
        r = ROOMS[g["room"]]
        out["room"] = {"index": g["room"], "name": r["name"], "topic": r["topic"], "intro": r["intro"],
                       "enemy": r["enemy"], "short": r["short"], "enemy_line": r["enemy_line"],
                       "warden_line": r["warden_line"]}
    elif phase == "question":
        cur = g["current"]
        q = cur["q"]
        elapsed = now() - cur["started"]
        out["question"] = {
            "id": cur["id"], "type": q["type"], "text": q["q"], "code": q["code"],
            "options": [o for o in cur["options"] if o not in cur["removed"]],
            "hint": (("ANSWER: " + q["answer"]) if g["god"] else q["hint"]) if cur["hint_used"] else None,
            "hint_locked": ability == "lockdown", "room": ROOMS[g["room"]]["name"],
            "enemy": ROOMS[g["room"]]["short"],
            "time_limit": cur["limit"], "crit_window": cur["crit_window"],
            "time_left": round(max(0.0, cur["limit"] - elapsed), 2) if cur["limit"] else None,
            "ability": cur["ability"]}
    elif phase == "feedback":
        out["feedback"] = g["feedback"]
    elif phase == "vault":
        v = g["vault"]
        out["vault"] = {"tries_left": v["tries_left"], "history": v["history"], "length": CODE_LENGTH,
                        "hint": v["revealed"], "hint_used": v["hint_used"], "max_tries": VAULT_TRIES,
                        "text": LINES["console"]}
    elif phase == "choice":
        out["choice"] = {"text": LINES["choice"]}
    elif phase == "room_clear":
        out["clear"] = g["clear"]
    elif phase == "end":
        out["end"] = dict(g["end"], review=g["missed"])
    return out
