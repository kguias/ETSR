import os
import uuid

from flask import Flask, jsonify, render_template, request, session

import game

app = Flask(__name__)
app.secret_key = os.urandom(24)
GAMES = {}


def current_game():
    return GAMES.get(session.get("gid"))


def respond(g, result=None):
    return jsonify({"state": game.view(g), "result": result or {}})


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/highscores")
def api_highscores():
    return jsonify(game.load_scores())


@app.route("/api/state")
def api_state():
    g = current_game()
    if g is None:
        return jsonify({"state": {"phase": "menu"}, "result": {}})
    return respond(g)


@app.route("/api/start", methods=["POST"])
def api_start():
    data = request.get_json(silent=True) or {}
    g = game.new_game(data.get("name"), data.get("difficulty"))
    gid = uuid.uuid4().hex
    GAMES[gid] = g
    session["gid"] = gid
    return respond(g)


@app.route("/api/<action>", methods=["POST"])
def api_action(action):
    g = current_game()
    if g is None:
        return jsonify({"state": {"phase": "menu"}, "result": {}})
    data = request.get_json(silent=True) or {}
    try:
        if action == "next":
            result = game.advance(g)
        elif action == "answer":
            result = game.answer(g, data.get("answer", ""))
        elif action == "hint":
            result = game.use_hint(g)
        elif action == "powerup":
            result = game.use_powerup(g, data.get("item"))
        elif action == "vault":
            result = game.vault_guess(g, data.get("guess", ""))
        elif action == "god":
            result = game.activate_god(g)
        elif action == "timeup":
            result = game.question_timeout(g)
        elif action == "choose":
            result = game.choose(g, data.get("choice"))
        else:
            return jsonify({"error": "Unknown action."}), 404
    except game.GameError as err:
        return jsonify({"error": str(err), "state": game.view(g)}), 400
    return respond(g, result)


if __name__ == "__main__":

    app.run(host="127.0.0.1", port=5000, debug=False)
